/* 
 * The main program for the Bank.
 *
 * You are free to change this as necessary.
 */

#include <string.h>
#include <sys/select.h>
#include <stdio.h>
#include <stdlib.h>
#include "bank.h"

int main(int argc, char**argv)
{
   int n;
   char recvline[1000];

   //catch SIGTERM in order to exit cleanly
   struct sigaction action;
   memset(&action, 0, sizeof(struct sigaction));
   action.sa_handler = bank_exit;
   sigaction(SIGTERM, &action, NULL);

   //Probably you should put something here to handle the command-line args

   Bank *bank = bank_create();

   fflush(stdout);

   while(1)
   {
         n = bank_recv(bank, recvline, 10000);
         bank_process_remote_command(bank, recvline, n);
   }

   return EXIT_SUCCESS;
}
